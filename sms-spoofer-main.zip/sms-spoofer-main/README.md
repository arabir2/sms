# sms-api
<p align="center">
<img src="https://call.zspoof.com/icon.png" height="60"><br>
SMS API Spoofer Tool for Sending SMS which whatever sender ID you want.<br>
                                      
</p>
<p align="center"><b>Our SMS API can support multiple languages and can accept almost any senderid you set it for.</b></p>

***WE WILL SALE FULL SOURCE FOR ONLY 300$***

### [+] Disclaimer :
***The SMS API aka SMS Spoofer tool is for educational purposes only. Iam not responsible if you missue it***


## Installation :
* `pip install -r requirements.txt`

#### Run : `python sms.py`


## [+] Follow Me :

[![Telegram](https://img.shields.io/badge/Chat-Telegram-blue?style=for-the-badge&logo=telegram)](https://t.me/zspoof)

<p>SMS spoofing is a technology which uses the short message service, available on most mobile phones and personal digital assistants, to set who the message appears to come from by replacing the originating mobile number with alphanumeric text. Spoofing has both legitimate uses and illegitimate uses. This can also send "mysterious" messages that look like they are from legitimate numbers or contacts.</p>

<p>Many people associate SMS spoofing with another technique called “smishing.” Some even believe them to be the same. While they both relate to phishing, however, both are quite different. Smishing, the short form of SMS phishing, is a security attack in which the user is tricked into downloading a Trojan horse, virus or other malware via a text message. And as you now know, SMS spoofing has to do with making a message look like it’s coming from another system or device.</p>
